#!/usr/bin/env bash
# p2p-read-kit: read-only characterization of GPU peer-to-peer READS. Changes no settings:
# no setpci, no BIOS, no driver reload. Run while the GPUs are otherwise idle (1-3 minutes).
#
#   bash run.sh [output-dir]
#   TRANSFERBENCH=/path/to/TransferBench bash run.sh     # optional extra TransferBench runs
#
# Run as root (or with passwordless sudo) to include full lspci capabilities and board/BIOS IDs.
# Send back the whole output directory (tar czf result.tgz <dir>).
set -u
HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
OUT=${1:-$PWD/p2p-read-kit-$(hostname -s)-$(date -u +%Y%m%dT%H%M%SZ)}
mkdir -p "$OUT"
exec > >(tee "$OUT/run.log") 2>&1
SUDO=""
if [ "$(id -u)" -ne 0 ] && sudo -n true 2>/dev/null; then SUDO="sudo -n"; fi
ROCM=${ROCM_PATH:-/opt/rocm}
export PATH="$ROCM/bin:$PATH"
echo "output: $OUT"

# ---- platform facts (read-only)
{
  echo "## host";    hostname; uname -r; grep PRETTY_NAME /etc/os-release
  echo "## cmdline"; cat /proc/cmdline
  echo "## cpu";     lscpu
  echo "## board and bios"
  if [ -n "$SUDO" ] || [ "$(id -u)" -eq 0 ]; then
    $SUDO dmidecode -t baseboard -t bios | grep -E 'Manufacturer|Product Name|Version|Release Date|BIOS Revision'
  else
    cat /sys/class/dmi/id/{board_vendor,board_name,bios_version,bios_date} 2>/dev/null
  fi
  echo "## rocm";    cat "$ROCM/.info/version" 2>/dev/null; hipconfig --version 2>/dev/null; echo
  echo "## amdgpu";  modinfo -F version amdgpu 2>/dev/null
} > "$OUT/platform.txt" 2>&1
grep -E 'Model name|NUMA node\(s\)' "$OUT/platform.txt"

# ---- build the probe for every GPU architecture present
ARCHS=$(rocminfo 2>/dev/null | awk '/^ *Name: *gfx/{print $2}' | sort -u)
[ -n "$ARCHS" ] || { echo "rocminfo found no gfx agents"; exit 1; }
FLAGS=""; for a in $ARCHS; do FLAGS="$FLAGS --offload-arch=$a"; done
hipcc -O3 $FLAGS -o "$OUT/p2p_probe" "$HERE/p2p_probe.cpp" || { echo "build failed"; exit 1; }
cp "$HERE/p2p_probe.cpp" "$HERE/run.sh" "$OUT/"

# ---- GPU list with root complex (host bridge) and root port of each
"$OUT/p2p_probe" list > "$OUT/gpus.txt" || exit 1
declare -A HB RP
{
  printf '%-4s %-13s %-12s %-14s %-22s %s\n' idx bdf host-bridge root-port 'root-port-max-link' arch/name
  while read -r idx bdf arch name; do
    bdf=${bdf,,}
    path=$(readlink -f "/sys/bus/pci/devices/$bdf")
    hb=$(echo "$path" | grep -oE 'pci[0-9a-f]{4}:[0-9a-f]{2}' | head -1)
    rp=$(echo "$path" | grep -oE '[0-9a-f]{4}:[0-9a-f]{2}:[0-9a-f]{2}\.[0-9]' | head -1)
    HB[$idx]=$hb; RP[$idx]=$rp
    lnk="$(cat /sys/bus/pci/devices/$rp/max_link_speed 2>/dev/null) x$(cat /sys/bus/pci/devices/$rp/max_link_width 2>/dev/null)"
    printf '%-4s %-13s %-12s %-14s %-22s %s %s\n' "$idx" "$bdf" "$hb" "$rp" "$lnk" "$arch" "$name"
  done < "$OUT/gpus.txt"
} > "$OUT/topology.txt"   # not a pipeline: HB/RP must stay in this shell
cat "$OUT/topology.txt"
N=$(wc -l < "$OUT/gpus.txt")

# ---- PCIe detail for every GPU and its root port, plus IOMMU domain types
{
  lspci -tv
  while read -r idx bdf _; do
    bdf=${bdf,,}
    for dev in "${RP[$idx]}" "$bdf"; do
      echo "=================== $dev"
      $SUDO lspci -vvv -s "$dev" 2>&1 | grep -E 'controller|bridge|DevCap|DevCtl|MaxPayload|MaxReadReq|LnkCap|LnkSta|LnkCtl|10Bit|ACSCap|ACSCtl|AtomicOps'
    done
    g=$(readlink -f "/sys/bus/pci/devices/$bdf/iommu_group" 2>/dev/null)
    echo "iommu group of $bdf: ${g##*/} type $(cat "$g/type" 2>/dev/null)"
  done < "$OUT/gpus.txt"
} > "$OUT/pcie.txt" 2>&1

aer() { for d in "${RP[@]}"; do for f in aer_dev_correctable aer_dev_nonfatal aer_dev_fatal; do
  [ -r "/sys/bus/pci/devices/$d/$f" ] && sed "s|^|$d $f |" "/sys/bus/pci/devices/$d/$f" | grep -v ' 0$'; done; done; }
aer > "$OUT/aer-before.txt"

# ---- probe every ordered GPU pair and pinned host memory
KS="1 16 64 256 1024"
for ((i = 0; i < N; ++i)); do
  "$OUT/p2p_probe" "$i" host $KS > "$OUT/probe-e$i-thost.log" 2>&1
  for ((j = 0; j < N; ++j)); do
    [ "$i" -eq "$j" ] && continue
    "$OUT/p2p_probe" "$i" "$j" $KS > "$OUT/probe-e$i-t$j.log" 2>&1
  done
done

# ---- summary: one row per path
lat() { awk '!/^#/ && $1==1 {printf "%.0f", $3}' "$1"; }
cap() { awk '!/^#/ {if ($4>m) m=$4} END {printf "%.1f", m}' "$1"; }
{
  echo "Read latency (1 outstanding) and ceiling on reads/s (max over K=$KS)."
  echo "Reference, ASRock Rack ROMED8-2T + EPYC 7532, R9700 x4: same root complex ~2.4 us / ~195 M/s;"
  echo "cross root complex ~2.4 us / ~15 M/s; host DRAM ~1.2 us / ~197 M/s."
  printf '%-14s %-12s -> %-14s %-12s %-6s %10s %12s\n' requester root target root class "lat ns" "ceiling M/s"
  for ((i = 0; i < N; ++i)); do
    f="$OUT/probe-e$i-thost.log"
    printf '%-14s %-12s -> %-14s %-12s %-6s %10s %12s\n' "$(sed -n "$((i+1))p" "$OUT/gpus.txt" | cut -d' ' -f2)" "${HB[$i]}" host-dram - host "$(lat "$f")" "$(cap "$f")"
    for ((j = 0; j < N; ++j)); do
      [ "$i" -eq "$j" ] && continue
      f="$OUT/probe-e$i-t$j.log"
      if grep -q 'NO PEER ACCESS' "$f"; then cls=nopeer; elif [ "${HB[$i]}" = "${HB[$j]}" ]; then cls=same; else cls=cross; fi
      printf '%-14s %-12s -> %-14s %-12s %-6s %10s %12s\n' "$(sed -n "$((i+1))p" "$OUT/gpus.txt" | cut -d' ' -f2)" "${HB[$i]}" \
        "$(sed -n "$((j+1))p" "$OUT/gpus.txt" | cut -d' ' -f2)" "${HB[$j]}" "$cls" "$(lat "$f")" "$(cap "$f")"
    done
  done
} | tee "$OUT/summary.txt"

# ---- optional TransferBench: pull vs push per pair, and shared-budget tests on one cross path
TB=${TRANSFERBENCH:-}
if [ -n "$TB" ] && [ -x "$TB" ]; then
  # GPU pairs only: with remote reads a CPU row makes the CPU read VRAM through the BAR (~0.07 GB/s)
  for RR in 1 0; do NUM_CPU_DEVICES=0 USE_REMOTE_READ=$RR "$TB" p2p 256M > "$OUT/tb-p2p-rr$RR.log" 2>&1; done
  # pick two GPUs (A,B) under one root complex and two (C,D) under another, if they exist
  mapfile -t BR < <(printf '%s\n' "${HB[@]}" | sort | uniq -c | awk '$1>=2{print $2}')
  if [ "${#BR[@]}" -ge 2 ]; then
    X=(); Y=()
    for ((i = 0; i < N; ++i)); do
      [ "${HB[$i]}" = "${BR[0]}" ] && X+=("$i"); [ "${HB[$i]}" = "${BR[1]}" ] && Y+=("$i")
    done
    A=${X[0]}; B=${X[1]}; C=${Y[0]}; D=${Y[1]}
    cat > "$OUT/tb-conc.cfg" <<EOF
# A=$A B=$B under ${BR[0]}; C=$C D=$D under ${BR[1]}. (src->exe->dst) with exe==dst is a pull.
1 16 (G$C->G$A->G$A)
2 16 (G$C->G$A->G$A) (G$C->G$B->G$B)
2 16 (G$C->G$A->G$A) (G$D->G$B->G$B)
2 16 (G$C->G$A->G$A) (G$A->G$C->G$C)
2 16 (G$C->G$A->G$A) (G$D->G$D->G$B)
EOF
    NUM_ITERATIONS=20 "$TB" "$OUT/tb-conc.cfg" 256M > "$OUT/tb-conc.log" 2>&1
  fi
fi

aer > "$OUT/aer-after.txt"
diff -q "$OUT/aer-before.txt" "$OUT/aer-after.txt" >/dev/null || echo "NOTE: PCIe AER counters changed during the run (see aer-*.txt)"
echo "done: $OUT"
