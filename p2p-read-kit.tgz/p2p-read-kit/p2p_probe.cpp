// p2p_probe: latency and request-ceiling probe for GPU reads of peer VRAM or pinned host DRAM.
// Read-only measurement: it allocates buffers and launches kernels, and changes no device setting.
//
// One executor GPU runs K independent pointer chases through a 256 MiB buffer that lives on a
// target (a peer GPU's VRAM, its own VRAM, or pinned host memory). Every step is a system-scope
// relaxed 4-byte load, so it is not served from the executor's caches and is a full round trip.
//   K = 1         -> unloaded round-trip latency of the path
//   K increasing  -> reads/s rises as K / latency until something caps the number in flight
//
// Usage: p2p_probe list
//        p2p_probe <exec_hip_index> <target_hip_index | host> [K ...]
#include <hip/hip_runtime.h>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <numeric>
#include <random>
#include <string>
#include <vector>

#define CK(x)                                                                                  \
  do {                                                                                         \
    hipError_t e_ = (x);                                                                       \
    if (e_ != hipSuccess) {                                                                    \
      std::fprintf(stderr, "%s:%d %s -> %s\n", __FILE__, __LINE__, #x, hipGetErrorString(e_)); \
      std::exit(2);                                                                            \
    }                                                                                          \
  } while (0)

__global__ void chase(const unsigned* __restrict__ buf, const unsigned* __restrict__ starts, int k,
                      int steps, unsigned* __restrict__ sink) {
  const int t = blockIdx.x * blockDim.x + threadIdx.x;
  if (t >= k) return;
  unsigned idx = starts[t];
  for (int i = 0; i < steps; ++i)
    idx = __hip_atomic_load(buf + idx, __ATOMIC_RELAXED, __HIP_MEMORY_SCOPE_SYSTEM);
  sink[t] = idx;
}

static int list_devices() {
  int n = 0;
  CK(hipGetDeviceCount(&n));
  for (int i = 0; i < n; ++i) {
    char bus[32];
    hipDeviceProp_t p{};
    CK(hipDeviceGetPCIBusId(bus, sizeof bus, i));
    CK(hipGetDeviceProperties(&p, i));
    std::printf("%d %s %s %s\n", i, bus, p.gcnArchName, p.name);
  }
  return 0;
}

int main(int argc, char** argv) {
  if (argc >= 2 && std::string(argv[1]) == "list") return list_devices();
  if (argc < 3) {
    std::fprintf(stderr, "usage: %s list | <exec_idx> <target_idx|host> [K...]\n", argv[0]);
    return 1;
  }
  const int exec = std::atoi(argv[1]);
  const bool host = std::string(argv[2]) == "host";
  const int target = host ? -1 : std::atoi(argv[2]);
  std::vector<int> ks;
  for (int i = 3; i < argc; ++i) ks.push_back(std::atoi(argv[i]));
  if (ks.empty()) ks = {1, 2, 4, 8, 16, 32, 48, 64, 96, 128, 256, 512, 1024, 2048};

  // 256 MiB of 512-byte nodes: far larger than L2 and any memory-side cache, and one node per
  // 512 B so consecutive steps never share a line or a PCIe read request.
  const size_t kNodeBytes = 512, kBufBytes = 256ull << 20;
  const size_t nodes = kBufBytes / kNodeBytes, stride = kNodeBytes / sizeof(unsigned);

  // Sattolo: one random cycle through every node.
  std::vector<unsigned> order(nodes);
  std::iota(order.begin(), order.end(), 0u);
  std::mt19937_64 rng(12345);
  for (size_t i = nodes - 1; i > 0; --i) {
    std::uniform_int_distribution<size_t> d(0, i - 1);
    std::swap(order[i], order[d(rng)]);
  }
  std::vector<unsigned> hostbuf(kBufBytes / sizeof(unsigned), 0);
  for (size_t i = 0; i < nodes; ++i)
    hostbuf[(size_t)order[i] * stride] = (unsigned)((size_t)order[(i + 1) % nodes] * stride);

  char ebus[32];
  CK(hipDeviceGetPCIBusId(ebus, sizeof ebus, exec));

  unsigned* buf = nullptr;
  std::string tname = "host-pinned";
  if (host) {
    CK(hipSetDevice(exec));
    CK(hipHostMalloc((void**)&buf, kBufBytes, hipHostMallocDefault));
    std::memcpy(buf, hostbuf.data(), kBufBytes);
  } else {
    char tbus[32];
    CK(hipDeviceGetPCIBusId(tbus, sizeof tbus, target));
    tname = tbus;
    CK(hipSetDevice(target));
    CK(hipMalloc((void**)&buf, kBufBytes));
    CK(hipMemcpy(buf, hostbuf.data(), kBufBytes, hipMemcpyHostToDevice));
    CK(hipDeviceSynchronize());
    if (target != exec) {
      int ok = 0;
      CK(hipDeviceCanAccessPeer(&ok, exec, target));
      if (!ok) {
        std::printf("# exec %s (hip %d)  target %s  NO PEER ACCESS\n", ebus, exec, tname.c_str());
        return 3;
      }
      CK(hipSetDevice(exec));
      hipError_t e = hipDeviceEnablePeerAccess(target, 0);
      if (e != hipSuccess && e != hipErrorPeerAccessAlreadyEnabled) CK(e);
      (void)hipGetLastError();
    }
  }
  CK(hipSetDevice(exec));

  const int kmax = *std::max_element(ks.begin(), ks.end());
  unsigned *starts = nullptr, *sink = nullptr;
  CK(hipMalloc((void**)&starts, kmax * sizeof(unsigned)));
  CK(hipMalloc((void**)&sink, kmax * sizeof(unsigned)));
  hipEvent_t a, b;
  CK(hipEventCreate(&a));
  CK(hipEventCreate(&b));

  std::printf("# exec %s (hip %d)  target %s  node %zu B  buffer %zu MiB\n", ebus, exec,
              tname.c_str(), kNodeBytes, kBufBytes >> 20);
  std::printf("# %6s %8s %12s %12s\n", "K", "steps", "ns/step", "Mreq/s");
  for (int k : ks) {
    // Chains start evenly spaced around the cycle, so they do not meet.
    std::vector<unsigned> st(k);
    for (int t = 0; t < k; ++t) st[t] = (unsigned)((size_t)order[(size_t)t * (nodes / k)] * stride);
    CK(hipMemcpy(starts, st.data(), k * sizeof(unsigned), hipMemcpyHostToDevice));
    const int steps = std::max(200, std::min(20000, (int)(nodes / k) - 1));
    const int threads = std::min(k, 64), blocks = (k + threads - 1) / threads;
    hipLaunchKernelGGL(chase, dim3(blocks), dim3(threads), 0, 0, buf, starts, k, 50, sink);
    CK(hipDeviceSynchronize());
    std::vector<double> ns;
    for (int rep = 0; rep < 3; ++rep) {
      CK(hipEventRecord(a, 0));
      hipLaunchKernelGGL(chase, dim3(blocks), dim3(threads), 0, 0, buf, starts, k, steps, sink);
      CK(hipEventRecord(b, 0));
      CK(hipEventSynchronize(b));
      float ms = 0;
      CK(hipEventElapsedTime(&ms, a, b));
      ns.push_back(ms * 1e6 / steps);
    }
    std::sort(ns.begin(), ns.end());
    const double per = ns[1];           // median ns per dependent step
    const double rate = k / per * 1e3;  // million reads per second
    std::printf("  %6d %8d %12.1f %12.2f\n", k, steps, per, rate);
    std::fflush(stdout);
  }
  return 0;
}
